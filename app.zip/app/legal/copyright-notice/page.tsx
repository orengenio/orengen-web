import type { Metadata } from "next";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import SiteRuntime from "@/components/site/SiteRuntime";
import ScrollProgress from "@/components/site/ScrollProgress";

/**
 * Copyright Notice (legal/policy document).
 * Re-skinned into the homepage brand system (shared shell + globals.css brand
 * classes). Wording is preserved verbatim from
 * Footer-pages/copyright-notice/page.html — only presentation/layout changed.
 */
export const metadata: Metadata = {
  title: "Copyright Notice",
  description:
    "Protecting intellectual property rights and DMCA compliance procedures.",
  keywords:
    "copyright-notice, OrenGen, OrenGen Worldwide, AI infrastructure, copyright notice",
  alternates: { canonical: "/legal/copyright-notice" },
  openGraph: {
    type: "website",
    title: "Copyright Notice",
    description:
      "Protecting intellectual property rights and DMCA compliance procedures.",
    url: "https://orengen.io/legal/copyright-notice",
    images: [
      "https://cdn.content360.io/ea2381f4-12e0-4efd-b95b-6012c981eae0/uploads/05-2026/0AVNQ9WDsFdbcEFJX0AQfTmktPcPu8V8GqAqNQS4.png",
    ],
  },
};

export default function CopyrightNoticePage() {
  return (
    <>
      <ScrollProgress />
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <div className="site-shell">
        <SiteHeader />
        <main id="main">
          {/* HERO */}
          <section
            className="section section-brand-blue"
            aria-label="Copyright Notice"
          >
            <div className="container">
              <header className="section-head reveal">
                <div className="eyebrow">Copyright Notice</div>
                <h1>Copyright Notice</h1>
                <p className="lead">
                  Protecting intellectual property rights and DMCA compliance
                  procedures.
                </p>
                <p className="lead">
                  <span>Last updated: May 2026</span>{" "}
                  <span>OrenGen Worldwide LLC</span> <span>Mansfield, TX</span>
                </p>
              </header>
            </div>
          </section>

          {/* DOCUMENT BODY */}
          <section
            className="section section-brand-white"
            aria-label="Document content"
          >
            <div className="container">
              <p>
                Protecting intellectual property rights and DMCA compliance
                procedures.
              </p>
              <p>Effective Date: January 1, 2026</p>
              <p>
                <strong>Respecting Intellectual Property:</strong> OrenGen
                Worldwide LLC respects the intellectual property rights of
                others and expects our users to do the same. This Copyright
                Notice explains our copyright ownership, DMCA procedures, and
                how to report copyright infringement.
              </p>

              <h2>1. OrenGen Copyright Ownership</h2>
              <p>
                <strong>
                  &copy; 2026 OrenGen Worldwide LLC. All Rights Reserved.
                </strong>
              </p>
              <p>
                Unless otherwise stated, all content, materials, software, code,
                designs, graphics, logos, trademarks, and other intellectual
                property on OrenGen&apos;s websites, platforms, and services are
                owned by or licensed to OrenGen Worldwide LLC and are protected
                by United States and international copyright laws, trademark
                laws, and other intellectual property rights.
              </p>

              <h3>1.1 Protected Works Include:</h3>
              <ul>
                <li>
                  <strong>Software and Code:</strong> All proprietary software,
                  source code, object code, algorithms, and technical
                  specifications
                </li>
                <li>
                  <strong>AI Technology:</strong> AI models, training data,
                  neural networks, and machine learning systems including
                  Buy-Lingual&trade; AI-Agents
                </li>
                <li>
                  <strong>Website Content:</strong> Text, articles, blog posts,
                  documentation, tutorials, and educational materials
                </li>
                <li>
                  <strong>Visual Content:</strong> Graphics, logos, icons,
                  images, photographs, videos, and animations
                </li>
                <li>
                  <strong>Audio Content:</strong> Voice recordings, audio clips,
                  sound effects, and music
                </li>
                <li>
                  <strong>User Interfaces:</strong> Design elements, layout,
                  navigation, user experience (UX), and user interface (UI)
                  designs
                </li>
                <li>
                  <strong>Marketing Materials:</strong> Advertisements,
                  promotional content, brochures, presentations, and sales
                  materials
                </li>
                <li>
                  <strong>Documentation:</strong> Technical documentation, API
                  references, user guides, and help resources
                </li>
              </ul>

              <h3>1.2 Copyright Notice Format</h3>
              <p>OrenGen&apos;s copyright notice appears as:</p>
              <p>
                <em>&copy; 2026 OrenGen Worldwide LLC. All Rights Reserved.</em>
              </p>
              <p>or</p>
              <p>
                <em>Copyright &copy; 2026 OrenGen Worldwide LLC</em>
              </p>

              <h3>1.3 Reservation of Rights</h3>
              <p>
                All rights not expressly granted in our{" "}
                <a href="/legal/terms">Terms and Conditions</a> are reserved by
                OrenGen. No license or right to use OrenGen&apos;s copyrighted
                materials is granted except as explicitly stated in writing.
              </p>

              <h2>2. User Rights and Restrictions</h2>
              <h3>2.1 Limited License to Use</h3>
              <p>
                Subject to your compliance with our Terms and Conditions,
                OrenGen grants you a limited, non-exclusive, non-transferable,
                revocable license to:
              </p>
              <ul>
                <li>Access and use our services for their intended purpose</li>
                <li>
                  View and download content for personal, non-commercial use
                </li>
                <li>Print individual pages for personal reference</li>
                <li>Share links to our publicly available content</li>
              </ul>

              <h3>2.2 Prohibited Uses</h3>
              <p>You may NOT, without express written permission from OrenGen:</p>
              <ul>
                <li>
                  <strong>Copy or Reproduce:</strong> Reproduce, duplicate,
                  copy, or redistribute substantial portions of our content
                </li>
                <li>
                  <strong>Modify or Create Derivatives:</strong> Modify, adapt,
                  translate, or create derivative works based on our materials
                </li>
                <li>
                  <strong>Reverse Engineer:</strong> Reverse engineer, decompile,
                  or disassemble our software or systems
                </li>
                <li>
                  <strong>Commercial Use:</strong> Use our content for commercial
                  purposes without a license
                </li>
                <li>
                  <strong>Remove Notices:</strong> Remove, alter, or obscure
                  copyright notices, trademarks, or other proprietary markings
                </li>
                <li>
                  <strong>Frame or Mirror:</strong> Frame, mirror, or inline link
                  to our content on other websites
                </li>
                <li>
                  <strong>Data Mining:</strong> Use automated tools to scrape,
                  extract, or harvest content from our platforms
                </li>
                <li>
                  <strong>Resell or Redistribute:</strong> Sell, rent, lease,
                  sublicense, or redistribute our copyrighted materials
                </li>
              </ul>

              <h2>3. User-Generated Content</h2>
              <h3>3.1 Your Content Ownership</h3>
              <p>
                You retain ownership of any content, data, files, or materials
                you upload, submit, or provide through OrenGen services
                (&quot;User Content&quot;). You do not transfer ownership to
                OrenGen.
              </p>

              <h3>3.2 License Grant to OrenGen</h3>
              <p>
                By uploading or submitting User Content to our services, you
                grant OrenGen a worldwide, non-exclusive, royalty-free,
                sublicensable, transferable license to:
              </p>
              <ul>
                <li>
                  Use, reproduce, store, and process your content to provide
                  services
                </li>
                <li>
                  Display, perform, and distribute your content as necessary for
                  service operation
                </li>
                <li>
                  Create derivative works for service improvement and AI training
                  (anonymized/aggregated where appropriate)
                </li>
                <li>Backup, archive, and secure your content</li>
              </ul>
              <p>
                This license terminates when you delete your content or close
                your account, except for content that has been shared with
                others or used in aggregated/anonymized data.
              </p>

              <h3>3.3 Your Representations and Warranties</h3>
              <p>
                When you submit User Content, you represent and warrant that:
              </p>
              <ul>
                <li>
                  You own or have necessary rights, licenses, and permissions to
                  use and grant rights to your content
                </li>
                <li>
                  Your content does not infringe copyrights, trademarks, or other
                  intellectual property rights
                </li>
                <li>
                  Your content complies with all applicable laws and our{" "}
                  <a href="/legal/acceptable-use">Acceptable Use Policy</a>
                </li>
                <li>
                  You have obtained all necessary consents and releases from
                  individuals featured in your content
                </li>
              </ul>

              <h3>3.4 User Content Restrictions</h3>
              <p>You may not upload or submit content that:</p>
              <ul>
                <li>
                  Infringes third-party copyrights, patents, trademarks, trade
                  secrets, or other rights
                </li>
                <li>
                  Contains unlicensed or unauthorized copyrighted material
                </li>
                <li>Violates rights of publicity or privacy</li>
                <li>Contains confidential information belonging to others</li>
              </ul>

              <h2>4. DMCA Notice and Takedown Procedure</h2>
              <p>
                OrenGen complies with the Digital Millennium Copyright Act
                (DMCA), 17 U.S.C. &#167; 512. We respond to valid notices of
                copyright infringement and will remove or disable access to
                infringing material when properly notified.
              </p>

              <h3>4.1 Designated DMCA Agent</h3>
              <p>
                OrenGen&apos;s designated agent to receive notifications of
                claimed copyright infringement is:
              </p>
              <h3>DMCA Agent Contact Information</h3>
              <p>
                <strong>Name:</strong> Copyright Agent
                <br />
                <strong>Company:</strong> OrenGen Worldwide LLC
                <br />
                <strong>Address:</strong> 1812 Open Range Drive, Mansfield, Texas
                76063
                <br />
                <strong>Email:</strong>{" "}
                <a href="mailto:support@orengen.io">support@orengen.io</a>
                <br />
                <strong>Subject Line:</strong> &quot;DMCA Takedown Notice&quot;
              </p>

              <h3>4.2 Filing a DMCA Takedown Notice</h3>
              <p>
                To file a DMCA takedown notice, you must provide a written
                communication that includes <strong>ALL</strong> of the
                following elements as required by 17 U.S.C. &#167; 512(c)(3):
              </p>
              <ol>
                <li>
                  <strong>Identification of Copyrighted Work:</strong> Identify
                  the copyrighted work you claim has been infringed. If multiple
                  works are involved, provide a representative list.
                </li>
                <li>
                  <strong>Identification of Infringing Material:</strong>{" "}
                  Identify the material that you claim is infringing and provide
                  sufficient information to locate it (e.g., specific URLs, file
                  names, account names, timestamps).
                </li>
                <li>
                  <strong>Contact Information:</strong> Provide your name,
                  address, telephone number, and email address so we can contact
                  you.
                </li>
                <li>
                  <strong>Good Faith Statement:</strong> Include the following
                  statement:{" "}
                  <em>
                    &quot;I have a good faith belief that the use of the
                    copyrighted material described above is not authorized by the
                    copyright owner, its agent, or the law.&quot;
                  </em>
                </li>
                <li>
                  <strong>Accuracy Statement:</strong> Include the following
                  statement:{" "}
                  <em>
                    &quot;I swear, under penalty of perjury, that the information
                    in this notification is accurate and that I am the copyright
                    owner or am authorized to act on behalf of the owner of an
                    exclusive right that is allegedly infringed.&quot;
                  </em>
                </li>
                <li>
                  <strong>Physical or Electronic Signature:</strong> Sign the
                  notice physically or electronically (typing your full legal
                  name constitutes an electronic signature).
                </li>
              </ol>

              <h3>4.3 Incomplete or Invalid Notices</h3>
              <p>
                DMCA notices that do not include all required elements will not
                be processed. We may contact you to request missing information,
                but we are not obligated to do so.
              </p>

              <h3>4.4 Our Response to Valid Notices</h3>
              <p>
                Upon receipt of a valid DMCA takedown notice, OrenGen will:
              </p>
              <ul>
                <li>
                  Promptly remove or disable access to the allegedly infringing
                  material
                </li>
                <li>
                  Notify the user who posted the material that it has been
                  removed
                </li>
                <li>Provide the user with a copy of the DMCA notice</li>
                <li>
                  Inform the user of their right to file a counter-notification
                </li>
              </ul>

              <h3>4.5 Processing Timeline</h3>
              <ul>
                <li>
                  Valid notices are typically processed within 1-3 business days
                </li>
                <li>
                  Expedited processing available for urgent cases (child
                  exploitation, identity theft, etc.)
                </li>
                <li>You will receive confirmation when action has been taken</li>
              </ul>

              <h2>5. DMCA Counter-Notification Procedure</h2>
              <p>
                If your content was removed due to a DMCA takedown notice and you
                believe the removal was improper or based on misidentification,
                you may file a counter-notification.
              </p>

              <h3>5.1 Filing a Counter-Notification</h3>
              <p>
                To file a DMCA counter-notification, send a written communication
                to our DMCA Agent (contact information above) that includes{" "}
                <strong>ALL</strong> of the following elements as required by 17
                U.S.C. &#167; 512(g)(3):
              </p>
              <ol>
                <li>
                  <strong>Your Contact Information:</strong> Your name, address,
                  telephone number, and email address.
                </li>
                <li>
                  <strong>Identification of Removed Material:</strong> Identify
                  the material that was removed and the location where it
                  appeared before removal.
                </li>
                <li>
                  <strong>Good Faith Statement:</strong> Include the following
                  statement:{" "}
                  <em>
                    &quot;I swear, under penalty of perjury, that I have a good
                    faith belief that the material was removed or disabled as a
                    result of mistake or misidentification of the material to be
                    removed or disabled.&quot;
                  </em>
                </li>
                <li>
                  <strong>Consent to Jurisdiction:</strong> Include the following
                  statement:{" "}
                  <em>
                    &quot;I consent to the jurisdiction of the Federal District
                    Court for the judicial district in which my address is
                    located (or the Northern District of Texas if my address is
                    outside the United States), and I will accept service of
                    process from the person who provided the original DMCA notice
                    or an agent of such person.&quot;
                  </em>
                </li>
                <li>
                  <strong>Physical or Electronic Signature:</strong> Sign the
                  counter-notification physically or electronically.
                </li>
              </ol>

              <h3>5.2 Our Response to Counter-Notifications</h3>
              <p>Upon receipt of a valid counter-notification:</p>
              <ul>
                <li>We will forward a copy to the original complainant</li>
                <li>
                  Inform them that we will restore the content in 10-14 business
                  days
                </li>
                <li>
                  Restore the content within 10-14 business days unless the
                  complainant files a court action seeking an injunction
                </li>
              </ul>

              <h3>5.3 Important Warning</h3>
              <p>
                <strong>
                  Filing a false or bad-faith counter-notification may result in
                  legal liability for damages, including attorneys&apos; fees and
                  court costs. Only file a counter-notification if you have a good
                  faith belief that the material was removed by mistake or
                  misidentification.
                </strong>
              </p>

              <h2>6. Repeat Infringer Policy</h2>
              <p>
                In accordance with the DMCA and other applicable laws, OrenGen
                has adopted a policy of terminating, in appropriate
                circumstances, the accounts of users who are deemed to be repeat
                infringers.
              </p>

              <h3>6.1 What Constitutes a Repeat Infringer</h3>
              <p>A repeat infringer is a user who:</p>
              <ul>
                <li>Has received two or more valid DMCA takedown notices</li>
                <li>
                  Has been notified of the infringement and failed to remove
                  infringing content
                </li>
                <li>
                  Demonstrates a pattern of uploading or sharing copyrighted
                  material without authorization
                </li>
                <li>
                  Has had multiple pieces of content removed for copyright
                  infringement
                </li>
              </ul>

              <h3>6.2 Actions We May Take</h3>
              <ul>
                <li>
                  <strong>First Violation:</strong> Warning and removal of
                  infringing content
                </li>
                <li>
                  <strong>Second Violation:</strong> Temporary suspension and
                  final warning
                </li>
                <li>
                  <strong>Third Violation:</strong> Permanent account termination
                  without refund
                </li>
              </ul>
              <p>
                We reserve the right to terminate accounts immediately for
                egregious violations or upon receipt of a court order.
              </p>

              <h3>6.3 No Obligation to Monitor</h3>
              <p>
                OrenGen is not obligated to monitor user content for copyright
                infringement. We act upon valid DMCA notices and rely on
                copyright owners to protect their rights.
              </p>

              <h2>7. Fair Use and Copyright Exceptions</h2>
              <h3>7.1 Fair Use Doctrine</h3>
              <p>
                U.S. copyright law permits limited use of copyrighted material
                without permission under the doctrine of &quot;fair use&quot; (17
                U.S.C. &#167; 107). Fair use may apply to:
              </p>
              <ul>
                <li>Commentary, criticism, and news reporting</li>
                <li>Educational and research purposes</li>
                <li>Parody and transformative works</li>
                <li>Search engines and indexing</li>
              </ul>
              <p>
                Fair use is determined on a case-by-case basis considering four
                factors:
              </p>
              <ol>
                <li>
                  Purpose and character of the use (commercial vs.
                  educational/transformative)
                </li>
                <li>Nature of the copyrighted work</li>
                <li>Amount and substantiality of the portion used</li>
                <li>Effect on the potential market for the original work</li>
              </ol>

              <h3>7.2 OrenGen Cannot Provide Legal Advice</h3>
              <p>
                OrenGen cannot determine whether a particular use constitutes
                fair use. If you believe your use qualifies as fair use and your
                content was removed, you may file a counter-notification. You may
                also wish to consult an attorney.
              </p>

              <h3>7.3 Safe Harbor Limitations</h3>
              <p>
                As a service provider, OrenGen qualifies for DMCA safe harbor
                protections (17 U.S.C. &#167; 512) when we comply with
                notice-and-takedown procedures. This means we are not liable for
                user-posted infringing content if we respond appropriately to
                valid DMCA notices.
              </p>

              <h2>8. International Copyright Protection</h2>
              <p>OrenGen&apos;s copyrighted works are protected internationally under:</p>
              <ul>
                <li>
                  <strong>Berne Convention:</strong> Automatic copyright
                  protection in 180+ countries
                </li>
                <li>
                  <strong>WIPO Copyright Treaty:</strong> International digital
                  copyright protections
                </li>
                <li>
                  <strong>Universal Copyright Convention:</strong> Additional
                  international protections
                </li>
                <li>
                  <strong>Trade Agreements:</strong> USMCA, EU-US agreements, and
                  bilateral treaties
                </li>
              </ul>
              <p>
                Copyright infringement may be prosecuted in multiple
                jurisdictions depending on the location of the infringer and the
                affected parties.
              </p>

              <h2>9. Reporting Other Intellectual Property Violations</h2>
              <p>
                For intellectual property violations that do not fall under DMCA
                (trademarks, patents, trade secrets, right of publicity), contact
                us at:
              </p>
              <ul>
                <li>
                  <strong>Trademark Violations:</strong> Email{" "}
                  <a href="mailto:support@orengen.io">support@orengen.io</a> with
                  subject &quot;Trademark Violation&quot;
                </li>
                <li>
                  <strong>Patent Violations:</strong> Email{" "}
                  <a href="mailto:support@orengen.io">support@orengen.io</a> with
                  subject &quot;Patent Infringement&quot;
                </li>
                <li>
                  <strong>Other IP Issues:</strong> Email{" "}
                  <a href="mailto:support@orengen.io">support@orengen.io</a> with
                  subject &quot;IP Violation&quot;
                </li>
              </ul>
              <p>
                Include detailed information about the violation, evidence, and
                your contact information.
              </p>

              <div
                aria-hidden="true"
                style={{ fontSize: "1.6rem", lineHeight: 1, marginBottom: "10px" }}
              >
                &#9888;&#65039;
              </div>
              <h3>Warning About False Claims</h3>
              <p>
                <strong>
                  Submitting a false, fraudulent, or bad-faith DMCA notice or
                  counter-notification may result in:
                </strong>
              </p>
              <ul>
                <li>
                  Civil liability for damages, costs, and attorneys&apos; fees
                  under 17 U.S.C. &#167; 512(f)
                </li>
                <li>
                  Criminal penalties for perjury under 18 U.S.C. &#167; 1621
                </li>
                <li>Legal action by affected parties</li>
                <li>Termination of your OrenGen account</li>
              </ul>
              <p>
                <strong>
                  Only file DMCA notices if you are the copyright owner or
                  authorized to act on their behalf. Only file
                  counter-notifications if you have a good faith belief the
                  content was removed by mistake.
                </strong>
              </p>

              <h3>Copyright and DMCA Inquiries</h3>
              <p>For copyright questions or to file DMCA notices:</p>
              <p>
                <strong>DMCA Agent:</strong> Copyright Agent
                <br />
                <strong>Email:</strong>{" "}
                <a href="mailto:support@orengen.io">support@orengen.io</a>
                <br />
                <strong>Subject Line:</strong> &quot;DMCA Takedown Notice&quot;
                or &quot;DMCA Counter-Notification&quot;
                <br />
                <strong>Mail:</strong> OrenGen Worldwide LLC
                <br />
                Attn: Copyright Agent / DMCA Notices
                <br />
                1812 Open Range Drive
                <br />
                Mansfield, Texas 76063
              </p>
              <p>
                <strong>Processing Time:</strong> Valid DMCA notices are
                processed within 1-3 business days.
              </p>
              <p>
                <strong>Copyright Statement:</strong> &copy; 2026 OrenGen
                Worldwide LLC. All rights reserved. All content, trademarks, and
                data on this website are the property of OrenGen Worldwide LLC or
                our licensors. Unauthorized reproduction, distribution, or use is
                strictly prohibited.
              </p>
            </div>
          </section>

          {/* FINAL CTA */}
          <section
            className="section alt section-brand-blue"
            aria-label="Contact OrenGen"
          >
            <div className="container">
              <header className="section-head center reveal">
                <h2>Have a question about this Copyright Notice?</h2>
                <p>
                  Reach the OrenGen team directly. We respond to copyright notice
                  inquiries within one business day.
                </p>
                <div className="cta-row">
                  <a
                    className="btn btn-primary"
                    href="mailto:legal@orengen.io?subject=copyright-notice"
                  >
                    Contact OrenGen
                  </a>
                </div>
              </header>
            </div>
          </section>
        </main>
        <SiteFooter />
        <SiteRuntime />
      </div>
    </>
  );
}
